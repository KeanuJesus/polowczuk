#ifndef fibonacci_h
#define fibonacci_h

long long fibonacci(int n);

#endif
